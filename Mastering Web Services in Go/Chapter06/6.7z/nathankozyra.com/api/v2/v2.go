package v2

import
(
	"nathankozyra.com/api/api"
)


func API() {

	api.StartServer()
}
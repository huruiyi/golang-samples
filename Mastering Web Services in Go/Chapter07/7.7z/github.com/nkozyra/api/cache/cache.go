package cache


import
(
	"log"
	"time"
)

const
(
	CacheMethod = "memory"
)

func Init() {

}

func SetCache() {
	
}

func GetCache() {
	
}